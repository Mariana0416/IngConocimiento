﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            System.Console.WriteLine("Bienvenido, seleccione una opción");
            string opcion;
            do
            {
                System.Console.WriteLine("1)Iniciar Juego");
                System.Console.WriteLine("2)Salir");

                opcion = Console.ReadLine();
                switch (opcion)
                {
                    case "1":
                        p.ClasificaciondeAnimales();
                        break;
                    case "2":
                        return;
                }
            } while (opcion != "2");
        }

        public void ClasificaciondeAnimales()
        {
            Console.Clear();
            string respuesta;
            System.Console.WriteLine("Piensa en un animal");
            System.Console.WriteLine("¿En que clasificación entra el animal en el que piensas?");
            System.Console.WriteLine("1) Mamífero");
            System.Console.WriteLine("2) Ovíparo");
            respuesta = Console.ReadLine();

            if (respuesta == "1" || respuesta == "Mamifero" || respuesta == "MAMIFERO" || respuesta == "sI")
            {
                System.Console.WriteLine("¿A que grupo pertenece según su alimentación?");
                System.Console.WriteLine("1) Carnívoro");
                System.Console.WriteLine("2) Herbívoro");
                System.Console.WriteLine("3) Omnívoro");

                String opcion1;

                opcion1 = Console.ReadLine();
                switch (opcion1)
                {
                    case "1":
                        CarnivoroMam();
                        break;
                    case "2":
                        HerbivoroMam();
                        break;
                    case "3":
                        OmnivoroMam();
                        return;
                }

            }
            else if (respuesta == "2" || respuesta == "OVIPARO" || respuesta == "oviparo" || respuesta == "Oviparo")
            {
                System.Console.WriteLine("¿A que grupo pertenece según su alimentación?");
                System.Console.WriteLine("1) Carnívoro");
                System.Console.WriteLine("2) Herbívoro");
                System.Console.WriteLine("3) Omnívoro");

                String opcion2;

                opcion2 = Console.ReadLine();
                switch (opcion2)
                {
                    case "1":
                        CarnivoroOvi();
                        break;
                    case "2":
                        HerbivoroOvi();
                        break;
                    case "3":
                        OmnivoroOvi();
                        return;
                }
            }
        }

        public void CarnivoroMam()
        {
            System.Console.WriteLine("¿El animal en el que estas pensando vive en ambientes acuaticos?");
            System.Console.WriteLine("1) Si");
            System.Console.WriteLine("2) No");
            string respuesta;
            respuesta = Console.ReadLine();
            if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
            {
               CMMarinos();
            }
            else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
            {
                System.Console.WriteLine("¿El animal en el que estas pensando un felino?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                   CMFelinos();
                }
                else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
                {
                    System.Console.WriteLine("¿El animal en el que estas pensando es un OSO?");
                    System.Console.WriteLine("1) Si");
                    System.Console.WriteLine("2) No");
                    respuesta = Console.ReadLine();
                    if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                    {
                        System.Console.WriteLine("Gracias por jugar");
                    }
                    else
                    {
                        System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                    }
                }
            }
        }

        public void CarnivoroOvi()
        {
            {
                System.Console.WriteLine("¿El animal en el que estas pensando vive en la Antártida?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                string respuesta;
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                    System.Console.WriteLine("¿El animal en el que estas pensando es un PINGÜINO?");
                    System.Console.WriteLine("1) Si");
                    System.Console.WriteLine("2) No");
                    respuesta = Console.ReadLine();
                    if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                    {
                        System.Console.WriteLine("Gracias por jugar");
                    }
                    else
                    {
                        System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                    }
                }
                else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
                {
                    System.Console.WriteLine("¿El animal en el que estas pensando es invertebrado?");
                    System.Console.WriteLine("1) Si");
                    System.Console.WriteLine("2) No");
                    respuesta = Console.ReadLine();
                    if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                    {
                        System.Console.WriteLine("¿El animal en el que estas pensando es un MEDUSA?");
                        System.Console.WriteLine("1) Si");
                        System.Console.WriteLine("2) No");
                        respuesta = Console.ReadLine();
                        if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                        {
                            System.Console.WriteLine("Gracias por jugar");
                        }
                        else
                        {
                            System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                        }
                    }
                    else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
                    {
                        System.Console.WriteLine("¿El animal en el que estas pensando es un TIBURON?");
                        System.Console.WriteLine("1) Si");
                        System.Console.WriteLine("2) No");
                        respuesta = Console.ReadLine();
                        if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                        {
                            System.Console.WriteLine("Gracias por jugar");
                        }
                        else
                        {
                            System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                        }
                    }
                }
            }
        }

        public void HerbivoroMam()
        {
            System.Console.WriteLine("¿El animal en el que estas pensando esta extinto?");
            System.Console.WriteLine("1) Si");
            System.Console.WriteLine("2) No");
            string respuesta;
            respuesta = Console.ReadLine();
            if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
            {
                System.Console.WriteLine("¿El animal en el que estas pensando es un MAMUT?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                    System.Console.WriteLine("Gracias por jugar");
                }
                else
                {
                    System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                }
            }
            else if(respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
            {
                System.Console.WriteLine("¿El animal en el que estas pensando es un tiene el cuello largo?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                    System.Console.WriteLine("¿El animal en el que estas pensando es una JIRAFA?");
                    System.Console.WriteLine("1) Si");
                    System.Console.WriteLine("2) No");
                    respuesta = Console.ReadLine();
                    if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                    {
                        System.Console.WriteLine("Gracias por jugar");
                    }
                    else
                    {
                        System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                    }
                }
                else if(respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
                {
                    System.Console.WriteLine("¿El animal en el que estas pensando es un roedor?");
                    System.Console.WriteLine("1) Si");
                    System.Console.WriteLine("2) No");
                    respuesta = Console.ReadLine();
                    if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si") {
                        System.Console.WriteLine("¿El animal en el que estas pensando es una ARDILLA?");
                        System.Console.WriteLine("1) Si");
                        System.Console.WriteLine("2) No");
                        respuesta = Console.ReadLine();
                        if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                        {
                            System.Console.WriteLine("Gracias por jugar");
                        }
                        else
                        {
                            System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                        }
                    }
                    else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
                    {
                        System.Console.WriteLine("¿El animal en el que estas pensando es un CONEJO?");
                        System.Console.WriteLine("1) Si");
                        System.Console.WriteLine("2) No");
                        respuesta = Console.ReadLine();
                        if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                        {
                            System.Console.WriteLine("Gracias por jugar");
                        }
                        else
                            {
                                System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                            }
                    }
                }
            }
        }

        public void HerbivoroOvi()
        {
            System.Console.WriteLine("¿El animal en el que estas pensando tiene caparazón?");
            System.Console.WriteLine("1) Si");
            System.Console.WriteLine("2) No");
            string respuesta;
            respuesta = Console.ReadLine();
            if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
            {
                System.Console.WriteLine("¿El animal en el que estas pensando es un TORTUGA?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                    System.Console.WriteLine("Gracias por jugar");
                }
                else
                {
                    System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                }
            }
            else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
            {
                System.Console.WriteLine("¿El animal en el que estas pensando le gusta cantar al amanecer?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                    System.Console.WriteLine("¿El animal en el que estas pensando es un GALLO?");
                    System.Console.WriteLine("1) Si");
                    System.Console.WriteLine("2) No");
                    respuesta = Console.ReadLine();
                    if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                    {
                        System.Console.WriteLine("Gracias por jugar");
                    }
                    else
                    {
                        System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                    }
                }
                else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
                {
                    System.Console.WriteLine("¿El animal en el que estas pensando es una MARIPOSA?");
                    System.Console.WriteLine("1) Si");
                    System.Console.WriteLine("2) No");
                    respuesta = Console.ReadLine();
                    if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                    {
                        System.Console.WriteLine("Gracias por jugar");
                    }
                    else
                    {
                        System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                    }
                }
            }
            
        }

        public void OmnivoroMam()
        {
            System.Console.WriteLine("¿El animal en el que estas pensando tiene fama de robar?");
            System.Console.WriteLine("1) Si");
            System.Console.WriteLine("2) No");
            string respuesta;
            respuesta = Console.ReadLine();
            if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
            {
                System.Console.WriteLine("¿El animal en el que estas pensando es un MAPACHE?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                    System.Console.WriteLine("Gracias por jugar");
                }
                else
                {
                    System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                }
            }
            else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
            {
                System.Console.WriteLine("¿El animal en el que estas pensando es el mejor amigo del hombre?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                    System.Console.WriteLine("¿El animal en el que estas pensando es un PERRO?");
                    System.Console.WriteLine("1) Si");
                    System.Console.WriteLine("2) No");
                    respuesta = Console.ReadLine();
                    if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                    {
                        System.Console.WriteLine("Gracias por jugar");
                    }
                    else
                    {
                        System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                    }
                }
                else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
                {
                    System.Console.WriteLine("¿El animal en el que estas pensando es un GATO?");
                    System.Console.WriteLine("1) Si");
                    System.Console.WriteLine("2) No");
                    respuesta = Console.ReadLine();
                    if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                    {
                        System.Console.WriteLine("Gracias por jugar");
                    }
                    else
                    {
                        System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                    }
                }
            }
        }

        public void OmnivoroOvi()
        {
            System.Console.WriteLine("¿El animal en el que estas pensando vive bajo la tierra?");
            System.Console.WriteLine("1) Si");
            System.Console.WriteLine("2) No");
            string respuesta;
            respuesta = Console.ReadLine();
            if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
            {
                System.Console.WriteLine("¿El animal en el que estas pensando es una HORMIGA?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                    System.Console.WriteLine("Gracias por jugar");
                }
                else
                {
                    System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                }
            }
            else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
            {
                System.Console.WriteLine("¿El animal en el que estas pensando es una MOSCA?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                    System.Console.WriteLine("Gracias por jugar");
                }
                else
                {
                    System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                }
            }
        }   

        public void CMFelinos(){
            System.Console.WriteLine("¿El animal en el que estas pensando es considerado el rey de la selva?");
            System.Console.WriteLine("1) Si");
            System.Console.WriteLine("2) No");
            string respuesta;
            respuesta = Console.ReadLine();
            if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
            {
                System.Console.WriteLine("¿El animal en el que estas pensando es un LEÓN?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                    System.Console.WriteLine("Gracias por jugar");
                }
                else
                {
                    System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                }
            }
            else if(respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
            {
                System.Console.WriteLine("¿El animal en el que estas pensando es el felino mas grande?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                    System.Console.WriteLine("¿El animal en el que estas pensando es una TIGRE?");
                    System.Console.WriteLine("1) Si");
                    System.Console.WriteLine("2) No");
                    respuesta = Console.ReadLine();
                    if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                    {
                        System.Console.WriteLine("Gracias por jugar");
                    }
                    else
                    {
                        System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                    }
                }
                else if(respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
                {
                    System.Console.WriteLine("¿El animal en el que estas pensando normalmente tiene el pelaje negro?");
                    System.Console.WriteLine("1) Si");
                    System.Console.WriteLine("2) No");
                    respuesta = Console.ReadLine();
                    if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si") {
                        System.Console.WriteLine("¿El animal en el que estas pensando es una PANTERA?");
                        System.Console.WriteLine("1) Si");
                        System.Console.WriteLine("2) No");
                        respuesta = Console.ReadLine();
                        if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                        {
                            System.Console.WriteLine("Gracias por jugar");
                        }
                        else
                        {
                            System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                        }
                    }
                    else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
                    {
                        System.Console.WriteLine("¿El animal en el que estas pensando tiene una marca de ropa inspirada en él?");
                        System.Console.WriteLine("1) Si");
                        System.Console.WriteLine("2) No");
                        respuesta = Console.ReadLine();
                        if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si"){
                            System.Console.WriteLine("¿El animal en el que estas pensando es un PUMA?");
                            System.Console.WriteLine("1) Si");
                            System.Console.WriteLine("2) No");
                            respuesta = Console.ReadLine();
                            if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                            {
                                System.Console.WriteLine("Gracias por jugar");
                            }
                            else
                            {
                                System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                            }
                        } else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
                        {
                            System.Console.WriteLine("¿El animal en el que estas pensando es un LEOPARDO?");
                            System.Console.WriteLine("1) Si");
                            System.Console.WriteLine("2) No");
                            respuesta = Console.ReadLine();
                            if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                            {
                                System.Console.WriteLine("Gracias por jugar");
                            }
                            else
                            {
                                System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                            }
                        }
                    }
                } 
            }
        } 

        public void CMMarinos(){
            System.Console.WriteLine("¿El animal en el que estas pensando es uno de los animales mas inteligentes del planeta?");
            System.Console.WriteLine("1) Si");
            System.Console.WriteLine("2) No");
            string respuesta;
            respuesta = Console.ReadLine();
            if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
            {
                System.Console.WriteLine("¿El animal en el que estas pensando es un DELFIN?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                    System.Console.WriteLine("Gracias por jugar");
                }
                else
                {
                    System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                }
            }
            else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
            {
                System.Console.WriteLine("¿El animal en el que estas pensando esta en peligro de extinción?");
                System.Console.WriteLine("1) Si");
                System.Console.WriteLine("2) No");
                respuesta = Console.ReadLine();
                if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                {
                    System.Console.WriteLine("¿El animal en el que estas pensando es una VAQUITA MARINA?");
                    System.Console.WriteLine("1) Si");
                    System.Console.WriteLine("2) No");
                    respuesta = Console.ReadLine();
                    if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                    {
                        System.Console.WriteLine("Gracias por jugar");
                    }
                    else
                    {
                        System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                    }
                }
                else if (respuesta == "2" || respuesta == "No" || respuesta == "NO" || respuesta == "no")
                {
                    System.Console.WriteLine("¿El animal en el que estas pensando es una FOCA?");
                    System.Console.WriteLine("1) Si");
                    System.Console.WriteLine("2) No");
                    respuesta = Console.ReadLine();
                    if (respuesta == "1" || respuesta == "SI" || respuesta == "si" || respuesta == "Si")
                    {
                        System.Console.WriteLine("Gracias por jugar");
                    }
                    else
                    {
                        System.Console.WriteLine("El animal en el que estas pensando no esta en la lista");
                    }
                }
            }
        } 

    }
}